package com.mycom.athletics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Logger;
import java.awt.Desktop;
import java.io.*;

//import com.sun.istack.internal.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.mycom.athletics.bean.*;
import com.mycom.athletics.dao.*;
import com.mycom.athletics.helper.*;
import java.sql.*;

public class ShowAthleteServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public ShowAthleteServlet()
	{
		super();
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		AthleticsDAO adao = new AthleticsDAO();
		Athletics athlete = new Athletics();
		List<Athletics> alist = new ArrayList<Athletics>();
		HttpSession session=request.getSession();
		System.out.println("servlet controller");
		try {
		alist=adao.showDetails();
		}
		 catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println( e.getMessage() );
			}
		session.setAttribute("alist",alist);// collection object can be set as seesion attribute
		
		RequestDispatcher reqDisp = 
				request.getRequestDispatcher("/showAthleteDetails.jsp");
		reqDisp.forward(request, response);
	}
	}


