package com.mycom.athletics.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.mycom.athletics.helper.*;

import com.mycom.athletics.bean.Athletics;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AthleticsDAO {
	private Connection connection = null;
	private PreparedStatement statement = null;
	private ResultSet resultSet = null;

	public static int insertAthlete(Athletics athlete) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
	  try
	  	{
	  		con=ConnectDB.getConnection();
	  		String ins_str ="insert into athletes values(?,?,?,?,?,?)";
			  pstmt = con.prepareStatement(ins_str);
			  pstmt.setString(1, athlete.getId());
			  pstmt.setString(2, athlete.getAname());
			  pstmt.setString(3, athlete.getGender());
			  pstmt.setString(4, athlete.getCategory());
			  pstmt.setString(5, athlete.getEmail());
			  pstmt.setLong(6, athlete.getMobileno());
			
			  int updateCount = pstmt.executeUpdate();
			  con.close();
			  return updateCount;
	  	}
	  catch(Exception e){
		  e.printStackTrace();
		  return 0;
	  }
		
	}

	public int deleteAthlete(String id) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
	  try
	  	{
	  		con=ConnectDB.getConnection();
	  		String del_str="delete from athletes where id =?";
	  		pstmt = con.prepareStatement(del_str);
	  		pstmt.setString(1, id);
	  				int updateCount = pstmt.executeUpdate();
			  con.close();
			  return updateCount;
	  	}
	  catch(Exception e){
		  e.printStackTrace();
		  return 0;
	  }
		
	}

	public ArrayList showDetails() throws ClassNotFoundException, SQLException
	{
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<Athletics> alist = new ArrayList<Athletics>();
		try {
			con = ConnectDB.getConnection();
			statement = con.prepareStatement("Select * from athletes");
			resultSet = statement.executeQuery();
			System.out.println("DAO LAyer");
			
			while(resultSet.next())
			{
				String aid;
				String aname;
				String gender;
				String category;
				String email;
				long mobile;
				
				Athletics athlete = new Athletics();
				
				aid = resultSet.getString(1);
				aname = resultSet.getString(2);
				gender = resultSet.getString(3);
				category = resultSet.getString(4);
				email = resultSet.getString(5);
				mobile = resultSet.getLong(6);
				
				athlete.setId(aid);
				athlete.setAname(aname);
				athlete.setGender(gender);
				athlete.setCategory(category);
				athlete.setEmail(email);
				athlete.setMobileno(mobile);
						
				alist.add(athlete);
				Iterator<Athletics> i = alist.iterator();
				while(i.hasNext())
				{
					System.out.println(i.next());
				}
				
			}
			
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
		}
		return alist;
		
	}

	public int updateAthlete(Athletics athlete) {
		// TODO Auto-generated method stub
		Connection con = null;
		PreparedStatement pstmt = null;
	  try
	  	{
	  		con=ConnectDB.getConnection();
	  		String ins_str ="update athletes SET name=?,gender=?,category=?,email=?,mobile=? WHERE id=?";
			  pstmt = con.prepareStatement(ins_str);

			  pstmt.setString(1, athlete.getAname());
			  pstmt.setString(2, athlete.getGender());
			  pstmt.setString(3, athlete.getCategory());
			  pstmt.setString(4, athlete.getEmail());
			  pstmt.setLong(5, athlete.getMobileno());
			  pstmt.setString(6, athlete.getId());
			  int updateCount = pstmt.executeUpdate();
			  con.close();
			  return updateCount;
	  	}
	  catch(Exception e){
		  e.printStackTrace();
		  return 0;
	  }
		

	}
}
		
	

	

