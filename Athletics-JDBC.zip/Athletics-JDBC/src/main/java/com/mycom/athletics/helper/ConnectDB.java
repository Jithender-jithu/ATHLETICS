package com.mycom.athletics.helper;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDB {
	public static Connection getConnection()
			  throws Exception
			  {
				Class.forName("com.mysql.jdbc.Driver");
				  Connection  conn = DriverManager.getConnection(
						  "jdbc:mysql://localhost:3306/athletics",
						  "root",
						  "root"); 
				
				  /*String driverName = "oracle.jdbc.driver.OracleDriver";
				  Class.forName(driverName);
				  Connection conn = DriverManager.getConnection(
				              "jdbc:oracle:thin:@localhost:1521:XE","deloittedb","deloittedb");*/
				
				return conn;
			  }
}
