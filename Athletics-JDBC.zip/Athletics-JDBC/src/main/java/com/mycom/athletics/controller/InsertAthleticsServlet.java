package com.mycom.athletics.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Random;
import java.util.logging.Logger;
import java.awt.Desktop;
import java.io.*;

//import com.sun.istack.internal.logging.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.mycom.athletics.bean.*;
import com.mycom.athletics.dao.*;
import com.mycom.athletics.helper.*;
import java.sql.*;
public class InsertAthleticsServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public InsertAthleticsServlet()
	{
		super();
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		AthleticsDAO adao = new AthleticsDAO();
		Athletics athlete = new Athletics();
		int rows = 0;
		String athName="";
		String gender="";
		String category="";
		String email="";
		long mobile;
		String aid;
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con=ConnectDB.getConnection();
			while(true) {
			Random r = new Random();
			String id = String.format("%04d", r.nextInt(10000));
			
			pstmt=con.prepareStatement("Select * from athletes where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(!rs.next()) {
				athlete.setId(id);
				System.out.println(id);
				break;
			}
			
			}
			con.close();
				
			
		} 
		
			catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		
		athName = request.getParameter("name");
		gender =  request.getParameter("gender");
		category = request.getParameter("category");
		email=request.getParameter("email");
		mobile=Long.parseLong(request.getParameter("mobile"));
		HttpSession session=request.getSession();
		
		System.out.println(athName);
		System.out.println(gender);
		System.out.println(category);
		System.out.println(email);
		System.out.println(mobile);
		
		
		athlete.setAname(athName);
		athlete.setCategory(category);
		athlete.setGender(gender);
		athlete.setEmail(email);
		athlete.setMobileno(mobile);
		
		try {
			rows = AthleticsDAO.insertAthlete(athlete);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		if( rows == 1) {
			//Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data successfully inserted");
			
			session.setAttribute("rows",rows);
			session.setAttribute("id", athlete.getId());
			System.out.println("Athlete data successfully inserted");
		} else {
			//Logger logger = Logger.getLogger(getClass());
			//logger.info("Book data could not insert");
			//out.println("Book data could not insert");
			session.setAttribute("rows",rows);
			System.out.println("Athlete data could not insert");
			
		}
		RequestDispatcher reqDisp = 
				request.getRequestDispatcher("/insert.jsp");
		reqDisp.forward(request, response);
		
	}
	}


